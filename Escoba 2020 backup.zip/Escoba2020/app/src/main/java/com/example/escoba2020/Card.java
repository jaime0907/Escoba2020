package com.example.escoba2020;

public class Card {
    private Integer palo;
    private Integer valor;
    private Boolean sel = false;
    private Boolean enPila = false;

    public Card(Integer palo, Integer valor) {
        this.palo = palo;
        this.valor = valor;
    }

    public Card(Integer palo, Integer valor, Boolean sel) {
        this.palo = palo;
        this.valor = valor;
        this.sel = sel;
    }

    public Integer getPalo() {
        return palo;
    }

    public void setPalo(Integer palo) {
        this.palo = palo;
    }

    public Integer getValor() {
        return valor;
    }

    public void setValor(Integer valor) {
        this.valor = valor;
    }

    public Boolean getSel() {
        return sel;
    }

    public void setSel(Boolean sel) {
        this.sel = sel;
    }

    public Boolean getEnPila() {
        return enPila;
    }

    public void setEnPila(Boolean enPila) {
        this.enPila = enPila;
    }
}
