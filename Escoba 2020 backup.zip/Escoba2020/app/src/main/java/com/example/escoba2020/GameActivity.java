package com.example.escoba2020;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.util.Pair;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout
import android.widget.RelativeLayout.LayoutParams;

import java.lang.annotation.Documented;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;

public class GameActivity extends AppCompatActivity {
    ArrayList<Card> baraja = new ArrayList<Card>();
    SparseArray<Card> listPlayerCards = new SparseArray<Card>();
    ArrayList<Card> listCenterCards = new ArrayList<Card>();

    Integer numCarta;

    public int getCardImageId(Card card){
        String mDrawableName = "card_" + card.getPalo().toString() + "_" + card.getValor().toString();
        if(!card.getSel()) {
            return getResources().getIdentifier(mDrawableName, "drawable", getPackageName());
        }else {
            return getResources().getIdentifier(mDrawableName + "_sel", "drawable", getPackageName());
        }
    }

    public void putCardInSlot(Integer cartaId, Card card){
        ImageView cardImage = ((ImageView)findViewById(cartaId));
        listPlayerCards.put(cardImage.getId(), card);
        cardImage.setImageResource(getCardImageId(card));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        numCarta = 0;

        for(int i = 1; i <= 4; i++){
            for(int j = 1; j <= 10; j++){
                baraja.add(new Card(i,j));
            }
        }
        Collections.shuffle(baraja);

        putCardInSlot(R.id.carta1, baraja.get(numCarta));
        numCarta++;
        putCardInSlot(R.id.carta2,baraja.get(numCarta));
        numCarta++;
        putCardInSlot(R.id.carta3,baraja.get(numCarta));
        numCarta++;
    }

    public void selectCard(View view){
        final ImageView cardImage = ((ImageView)view);
        Card card = listPlayerCards.get(cardImage.getId());

        card.setSel(!card.getSel());
        cardImage.setImageResource(getCardImageId(card));
    }

    public void makePlay(View view){
        for(int i = 0; i < listPlayerCards.size(); i++) {
            int key = listPlayerCards.keyAt(i);
            Card card = listPlayerCards.get(key);
            if(card.getSel()){
                ImageView cardImage = (ImageView)findViewById(key);
                selectCard(cardImage);
                moveCard(cardImage, (ImageView)findViewById(R.id.pila));
            }
        }
    }

    public void moveCard(ImageView cardImage, ImageView pila){
        Card card = listPlayerCards.get(cardImage.getId());

        ImageView newCardImage = new ImageView(getApplicationContext());
        newCardImage.setImageResource(getCardImageId(card));
        newCardImage.setLayoutParams(cardImage.getLayoutParams());
        newCardImage.setX(cardImage.getX());
        newCardImage.setY(cardImage.getY());

        ConstraintLayout game_layout = (ConstraintLayout)findViewById(R.id.game_layout);
        game_layout.addView(newCardImage);

        float x = (float)(pila.getX() + Math.random()*10);
        float y = (float)(pila.getY() + Math.random()*10);
        ObjectAnimator animX = ObjectAnimator.ofFloat(newCardImage, "x", x);
        ObjectAnimator animY = ObjectAnimator.ofFloat(newCardImage, "y", y);
        ObjectAnimator animRot = ObjectAnimator.ofFloat(newCardImage, "rotation", 0, (float)(Math.random()-0.5)*10);
        AnimatorSet animSetXY = new AnimatorSet();
        animSetXY.playTogether(animX, animY, animRot);
        animSetXY.setDuration(1000);
        animSetXY.start();
        flipCard(newCardImage);
    }

    public void flipCard(View view){
        final ImageView cardImage = ((ImageView)view);

        ObjectAnimator anim = ObjectAnimator.ofFloat(cardImage, "rotationY", 0, 180);
        anim.setDuration(1000);
        anim.start();
        cardImage.postDelayed(new Runnable(){
            @Override
            public void run() {
                cardImage.setImageResource(R.drawable.card_back);
            }
        }, 500);
    }

    public void addCardToCenter(Card card){
        switch(listCenterCards.size()){
            case 0:
                break;
            default:
                ImageView newCardImage = new ImageView(getApplicationContext());
                newCardImage.setImageResource(getCardImageId(card));
                LayoutParams lp = new LayoutParams()
                newCardImage.setLayoutParams(cardImage.getLayoutParams());

                ConstraintLayout center_layout = (ConstraintLayout)findViewById(R.id.center_layout);
                center_layout.addView(newCardImage);
        }
    }

    public void throwCard(View view){
        for(int i = 0; i < listPlayerCards.size(); i++) {
            int key = listPlayerCards.keyAt(i);
            Card card = listPlayerCards.get(key);
            if(card.getSel()){
                ImageView cardImage = (ImageView)findViewById(key);
                selectCard(cardImage);
                addCardToCenter(card);
            }
        }
    }
}
